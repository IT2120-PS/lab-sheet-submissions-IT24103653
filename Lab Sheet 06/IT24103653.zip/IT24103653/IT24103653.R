setwd("C:\\Users\\ayody\\OneDrive\\Desktop\\IT24103653")

#Exercise 01
n <- 50        # number of students
p <- 0.85      # probability of success (pass)

# (i) Distribution of X
X ~ Binomial(n=50, p=0.85)

# (ii) Probability that at least 47 students passed
# P(X >= 47) = 1 - P(X <= 46)
prob_at_least_47 <- 1 - pbinom(46, size=n, prob=p)
prob_at_least_47



# Exercise 02
lambda <- 12   # average calls per hour

# (i) Random variable 
#X = number of calls received in an hour

# (ii) Distribution of X
X ~ Poisson(lambda = 12)

# (iii) Probability that exactly 15 calls are received
prob_15_calls <- dpois(15, lambda)
prob_15_calls
