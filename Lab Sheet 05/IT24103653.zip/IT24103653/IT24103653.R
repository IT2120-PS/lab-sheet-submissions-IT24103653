#Exercise

#Question_01
setwd("C:\\Users\\ayody\\OneDrive\\Desktop\\IT24103653")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(Delivery_Times)

#Question_02
breaks <- seq(20, 70, length.out = 10)
hist(Delivery_Times$Delivery_Time,
     breaks = breaks,
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     col = "green",
     border = "black")

#Question_03
#The distribution of delivery times is approximately symmetric and bell-shaped.Most 
#deliveries cluster around 40 minutes, with fewer very short or very long delivery times.
#This creates a slight right skew, meaning a few deliveries take longer than the typical 
#delivery time. 

#Question_04
histogram <- hist(Delivery_Times$Delivery_Time,
                  breaks = seq(20, 70, length.out = 10),
                  right = FALSE,
                  plot = FALSE)

breaks <- histogram$breaks
freq <- histogram$counts

classes <- c()
for(i in 1:(length(breaks) - 1)) {
  classes[i] <- paste0("[", breaks[i], ", ", breaks[i+1], ")")
}

freq_table <- cbind(Class_Interval = classes, Frequency = freq)
print(freq_table)

cum_freq <- cumsum(freq)

cum_freq_with0 <- c(0, cum_freq)

plot(breaks, cum_freq_with0, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "red", pch = 16)

cum_table <- cbind(Upper_Class = breaks, Cum_Freq = cum_freq_with0)
print(cum_table)